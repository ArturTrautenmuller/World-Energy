ExtractPath = 'C:\\TERZ\\TERZ_Project\\World Energy\\Extract'
TransformPath = 'C:\\TERZ\\TERZ_Project\\World Energy\\Transform'
ME_TransformPath = 'C:\\TERZ\\TERZ_Project\\MacroEconomy\\Transform'
ResourcesPath = 'C:\\TERZ\\TERZ_Project\\World Energy\\Resources'