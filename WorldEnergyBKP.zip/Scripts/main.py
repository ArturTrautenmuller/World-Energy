import numpy as np
import pandas as pd
import variables
import Transform_Primary
import Transform_Eletricity
import Transform_Geral

Transform_Primary.TransformPrimary()
Transform_Eletricity.TransformEletricity()
Transform_Geral.Geral()







